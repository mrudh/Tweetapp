package com.tweetapp.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TweetAppDao {
	
	private Connection connection;
	public boolean isConnectionSuccess = false;

	public TweetAppDao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tweetapp","root","root");
			this.isConnectionSuccess = true;
		} catch(Exception e){ 
			System.out.println("Error while connecting to database - " + e);
			this.connection = null;
			this.isConnectionSuccess = false;
		}
	}
	
	public ResultSet selectQuery(String query) {
		if(this.connection != null) {
			try {
				Statement stmt= this.connection.createStatement();  
				ResultSet result = stmt.executeQuery(query);
				stmt = null;
				return result;
			}catch(Exception e){ 
				System.out.println("Error while running execute query - " + e);
			}  
		}
		return null;
	}
	
	public int updateQuery(String query) {
		if(this.connection != null) {
			try {
				Statement stmt= this.connection.createStatement();  
				int result = stmt.executeUpdate(query); 
				stmt = null;
				System.out.println(result);
				return result;
			}catch(Exception e){ 
				System.out.println("Error while running upsert query - " + e);
			}  
		}
		return -1;
	}
	
	public void finalize()  
	{  
		try {
			this.connection.close();
			this.connection = null;
		} catch (SQLException e) {
			System.out.println("Error while closing database connection - " + e);
		}
	}

}
