package com.tweetapp.Service;

import java.sql.ResultSet;

import com.tweetapp.Dao.TweetAppDao;

public class UserClass {
	
	private String userName = "";
	private int userId;
	
	private TweetAppDao db = new TweetAppDao();

	public UserClass() {
		this.userId = 0;
	}
	
	public boolean login(String email,String password) {
		String getUserQuery = "SELECT user_id, first_name, last_name FROM user_details WHERE email = '" + email + "' and password ='" + password + "';";
		ResultSet result = db.selectQuery(getUserQuery);
		try {
			result.next();
			this.userName = result.getString("first_name") + " " + result.getString("last_name");
			this.userId = result.getInt("user_id");
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public String getUserName() {
		return userName;
	}
	
	public void finalize() {
		db.finalize();
		db = null;
	}

	public boolean postTweet(String tweet) {
		String postTweetQuery ="INSERT INTO tweet_table (user_id, tweet, tweet_date) values(" + this.userId + ", '" + tweet + "', curDate());";
		try {
			if(db.updateQuery(postTweetQuery) > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			System.out.println("Some error occured " + e);
			return false;
		}
	}

	public void viewTweet(boolean isUser) {
		String viewTweetQuery;
		if(isUser) {
			viewTweetQuery = "SELECT a.tweet_date, a.tweet, b.first_name,  b.last_name FROM tweet_table as a LEFT JOIN user_details as b ON a.user_id = b.user_id WHERE a.user_id = " + this.userId + ";";
		} else {
			viewTweetQuery = "SELECT a.tweet_date, a.tweet, b.first_name,  b.last_name FROM tweet_table as a LEFT JOIN user_details as b ON a.user_id = b.user_id;";
		}
		ResultSet result = db.selectQuery(viewTweetQuery);
		try {
			if (isUser) {
				System.out.println("\nView My Tweets");
			} else {
				System.out.println("\nView All Tweets");
			}
			while(result.next()) {
				System.out.println(result.getString("tweet_date") + " : " + result.getString("first_name") + " " + result.getString("last_name") + " - " + result.getString("tweet"));
			}			
		} catch (Exception e) {
			System.out.println("\nSome error occured " + e);
		}
	}

	public boolean changePassword(String oldPassword, String newPassword) {
		String changePasswordQuery ="UPDATE user_details SET password = '" + newPassword + "' WHERE user_id = " + this.userId + " and password = '" + oldPassword + "';";
		try {
			if(db.updateQuery(changePasswordQuery) > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			System.out.println("Some error occured " + e);
			return false;
		}		
	}
	
}
