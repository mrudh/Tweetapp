package com.tweetapp.Service;

import java.util.Scanner;

import com.tweetapp.Dao.TweetAppDao;

public class NewUserRegister {
	
	private String firstName;
	private String lastName;
	private String gender;
	private String dob;
	private String email;
	private String password;
	
	private TweetAppDao db = new TweetAppDao();

	public NewUserRegister() {
		this.firstName = "";
		this.lastName = "";
		this.gender = "";
		this.dob = "";
		this.email = "";
		this.password = "";
	}

	public boolean enterDetails(Scanner scanner) {
		if(db.isConnectionSuccess == false) {
			return false;
		}
		System.out.println("\nSign Up");
		
		System.out.println("First Name : ");
		this.firstName = scanner.nextLine().trim();
		
		System.out.println("Last Name : ");
		this.lastName = scanner.nextLine().trim();
		
		System.out.println("Gender (M/F): ");
		this.gender = scanner.next().trim();
		this.gender.toUpperCase();
		scanner.nextLine();
		
		System.out.println("Date of Birth (YYYY-MM-DD): ");
		this.dob = scanner.next().trim();
		scanner.nextLine();
		
		System.out.println("Email / Username : ");
		this.email = scanner.next().trim();
		scanner.nextLine();
		
		System.out.println("Password : ");
		this.password = scanner.next().trim();
		scanner.nextLine();
		
		return true;
	}
	
	public boolean registerNewUser() {
		String query = "INSERT INTO user_details (first_name, last_name, gender, dob, email, password) values('" + this.firstName + "', '" + this.lastName + "', '" + this.gender + "', '" + this.dob + "', '" + this.email + "', '" + this.password + "')";
		try {
			if(db.updateQuery(query) > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			System.out.println("Some error occured " + e);
			return false;
		}
	}
	
	public boolean forgotPassword(String userName, String password) {
		String changePasswordQuery ="UPDATE user_details SET password = '" + password + "' WHERE email = '" + userName + "';";
		try {
			if(db.updateQuery(changePasswordQuery) > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			System.out.println("Some error occured " + e);
			return false;
		}
	}
	
	public void finalize() {
		db.finalize();
		db = null;
	}
	
}
