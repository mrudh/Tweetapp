package com.tweetapp;

import java.util.Scanner;

import com.tweetapp.Service.NewUserRegister;
import com.tweetapp.Service.UserClass;

public class Menu {
	
	private static boolean isLoggedIn = false;
	private static String userName = "";
	private static int menuOption = 0;
	private static String[] menu = {
			"Register",
			"Login",
			"Forgot Password",
			"Exit"
	};
	private static String[] loggedInMenu = {
			"Post a tweet",
			"View my tweets",
			"View all tweets",
			"Reset Password",
			"Logout"
	};
	private static NewUserRegister newUser;
	private static UserClass user;
	private static Scanner scanner;
	
	public static void startApplication() {
		
		while((menuOption != 4 && isLoggedIn == false) || isLoggedIn == true) {
			showMenu();
		}
		scanner.close();
		scanner = null;
		user = null;

	}
	
	private static void showMenu() {
		scanner = new Scanner(System.in);
		String[] menuList = (isLoggedIn == true)? loggedInMenu: menu;
		String heading = (isLoggedIn == true)? "Hello " + userName + ",": "Menu";
		
		System.out.println("\n\n===============================================\n");
		System.out.println(heading + "\n");
		for(int i = 0; i < menuList.length; i++) {
			System.out.println( (i+1) + ". " + menuList[i]);
		}
		System.out.println("Please select an option : ");
		String selectedOption = scanner.next();
		scanner.nextLine();
		try {
			menuOption = Integer.parseInt(selectedOption);
			if(isLoggedIn == false && (menuOption < 1 || menuOption > 4)) {
				throw new Exception();
			} else if(isLoggedIn == true && (menuOption < 1 || menuOption > 5)) {
				throw new Exception();
			} else {
				doMenuOperation();
			}
		} catch (Exception e) {
			menuOption = 0;
			System.out.println("Invalid Option! Please select a valid option");
		}
		
	}
	
	private static void doMenuOperation() {
		if(isLoggedIn == true) {
			switch (menuOption) {
			case 1:
				System.out.println("\nPlease enter the tweet (max 250 characters) : ");
				String tweet = scanner.nextLine();
				if(user.postTweet(tweet)) {
					System.out.println("\nPosted tweet successfully");
				} else {
					System.out.println("\nSome error occured couldn't post your tweet!!");
				}
				break;
			case 2:
				user.viewTweet(true);
				break;
			case 3:
				user.viewTweet(false);
				break;
			case 4:
				System.out.println("\nEnter old password :");
				String oldPassword = scanner.nextLine();
				System.out.println("Enter new password :");
				String newPassword = scanner.nextLine();
				if(user.changePassword(oldPassword, newPassword)) {
					System.out.println("\nChanged password successfully");
				} else {
					System.out.println("\nSome error occured couldn't change password!!");
				}
				break;
			case 5:
				user = null;
				isLoggedIn = false;
				userName = "";
				System.out.println("\nLogged out successfully !!");
				break;
			default:
				break;
			}
		} else if(isLoggedIn == false) {
			switch (menuOption) {
			case 1:
				newUser = new NewUserRegister();
				if(newUser.enterDetails(scanner)) {
					if(newUser.registerNewUser()) {
						System.out.println("New User created successfully.");
						newUser.finalize();
						newUser = null;
					} else {
						System.out.println("Some error occured please try again.");
						newUser.finalize();
						newUser = null;
					}
				} else {
					System.out.println("Some error occured please try again.");
					newUser.finalize();
					newUser = null;
				}
				break;
			case 2:
				user = new UserClass();
				String email = "";
				String password = "";
				System.out.println("\nSign In");
				System.out.println("Email / Username : ");
				email = scanner.next().trim();
				scanner.nextLine();
				System.out.println("Password : ");
				password = scanner.next().trim();
				scanner.nextLine();
				if(user.login(email, password) == true) {
					isLoggedIn = true;
					userName = user.getUserName();
				} else {
					System.out.println("\nInvalid username or password!!");
					user.finalize();
					user = null;
				}
				break;
			case 3:
				newUser = new NewUserRegister();
				System.out.println("\nEnter Email / Username :");
				String userName = scanner.nextLine();
				System.out.println("Enter new password :");
				String newPassword = scanner.nextLine();
				if(newUser.forgotPassword(userName, newPassword)) {
					System.out.println("\nPassword reset successfully");
				} else {
					System.out.println("\nSome error occured couldn't change password!!");
				}
				break;
			case 4:
				System.out.println("\nExiting Application.\nThanks for using TweetApp. Please come again.");
				break;
			default:
				break;
			}
		}
	}
	
}
