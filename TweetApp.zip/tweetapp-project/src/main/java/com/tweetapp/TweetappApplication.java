package com.tweetapp;

public class TweetappApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu.startApplication();
	}

}
